import React from 'react'

export default function GoalCard() {
  return (
    <div>GoalCard</div>
  )
}
