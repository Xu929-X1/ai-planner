import React from 'react';
import GoalInput from '../components/GoalInput';

const Planner: React.FC = () => {
    return (
        <div>
            <GoalInput />
        </div>
    );
};

export default Planner;